GRAFOS POR ALEXANDER NARVÁEZ


El presente es un proyecto que realicé como código base para mis estudiantes de Estructuras de datos 2.
Consite en una interfaz gráfica desarrolalda con PyQt, que es una librería de C++ para desarrollar UIs en Python.
El programa permite generar matrices de pesos y a partir de ellas contruir un grafo.
La distribución de los vértices se hace aleatoria, pero el programa está disñedo para que se puedan arrastrar los nodos junto con us aristas.
También se puede cliquear sobre un arco el cual aparecerá resaltado en color rojo junto con los nodos que van conectados por esa arista.
![image](https://github.com/user-attachments/assets/c4b02bcf-e322-4fde-9e2d-9c460233369c)

La idea es que puedan usar este código para que lo personalicen de modo que pueda extender las capacidades del mismo, por ejemplo añadir la funcionalidad de que el programa encuentre las k trayectorias aplicando el algoritmo de Dijkstra o del Bellman - Ford.

P.D., importantísimo: recuerda darle clic en la estrellita antes de descargar( o te Hackeo el feisbuk ;) )
