import sys
import random
from PyQt5 import QtWidgets, QtGui, QtCore
from PyQt5.QtWidgets import QGraphicsScene, QGraphicsEllipseItem, QGraphicsLineItem, QGraphicsTextItem, QGraphicsItem
from grafos_ui import Ui_MainWindow  # Suponiendo que tienes la interfaz generada con Qt Designer


class Nodo(QGraphicsEllipseItem):
    def __init__(self, x, y, radius, id, app):
        super().__init__(-radius, -radius, 2 * radius, 2 * radius)
        self.setBrush(QtGui.QBrush(QtGui.QColor("lightblue")))
        self.setPen(QtGui.QPen(QtCore.Qt.black))
        self.id = id
        self.setFlag(QGraphicsEllipseItem.ItemIsMovable)
        self.setFlag(QGraphicsEllipseItem.ItemSendsGeometryChanges)
        self.text_item = QGraphicsTextItem(f"Nodo {self.id}", self)
        self.text_item.setPos(-10, -10)
        self.app = app
        self.aristas = []

    def agregar_arista(self, arista):
        self.aristas.append(arista)

    def itemChange(self, change, value):
        if change == QGraphicsItem.ItemPositionChange:
            for arista in self.aristas:
                arista.actualizar_posiciones()
        return super().itemChange(change, value)


class Arista(QGraphicsLineItem):
    def __init__(self, nodo1, nodo2, peso, scene):
        super().__init__()
        self.nodo1 = nodo1
        self.nodo2 = nodo2
        self.peso = peso
        self.scene = scene
        self.text_item = QGraphicsTextItem(str(self.peso))
        self.scene.addItem(self.text_item)
        self.actualizar_posiciones()
        self.setFlag(QGraphicsLineItem.ItemIsSelectable)
        self.setPen(QtGui.QPen(QtCore.Qt.black))

    def actualizar_posiciones(self):
        x1, y1 = self.nodo1.scenePos().x(), self.nodo1.scenePos().y()
        x2, y2 = self.nodo2.scenePos().x(), self.nodo2.scenePos().y()
        self.setLine(x1, y1, x2, y2)
        self.text_item.setPos((x1 + x2) / 2, (y1 + y2) / 2)


class GrafoApp(QtWidgets.QMainWindow):
    def __init__(self):
        super(GrafoApp, self).__init__()
        self.ui = Ui_MainWindow()
        self.ui.setupUi(self)
        self.graphicsView = self.ui.graphicsView
        self.scene = QGraphicsScene()
        self.graphicsView.setScene(self.scene)
        self.ui.btnPintarGrafo.clicked.connect(self.dibujar_grafo)
        self.nodos = []
        self.aristas = []

    def obtener_matriz_pesos(self):
        """
        Obtener los valores de la matriz de pesos desde el QTableWidget.
        """
        filas = self.ui.tableWidget.rowCount()  # Número de filas
        columnas = self.ui.tableWidget.columnCount()  # Número de columnas
        matriz_pesos = []

        # Leer los valores de la tabla y convertirlos en una matriz de pesos
        for i in range(filas):
            fila = []
            for j in range(columnas):
                item = self.ui.tableWidget.item(i, j)  # Obtener la celda (item)
                if item is not None and item.text() != "":
                    try:
                        valor = int(item.text())  # Convertir el valor a entero
                    except ValueError:
                        valor = 0  # Si no es un número válido, asignamos 0
                else:
                    valor = 0  # Si la celda está vacía, asignamos 0
                fila.append(valor)
            matriz_pesos.append(fila)

        return matriz_pesos

    def matriz_pesos_a_adyacencia(self, matriz_pesos):
        return [[1 if peso != 0 else 0 for peso in fila] for fila in matriz_pesos]

    def actualizar_tabla(self, tabla, matriz):
        tabla.setRowCount(len(matriz))
        tabla.setColumnCount(len(matriz))
        for i, fila in enumerate(matriz):
            for j, valor in enumerate(fila):
                item = QtWidgets.QTableWidgetItem(str(valor))
                item.setTextAlignment(QtCore.Qt.AlignCenter)
                tabla.setItem(i, j, item)

    def calcular_potencia_matriz(self, matriz, k):
        n = len(matriz)
        resultado = [[0] * n for _ in range(n)]
        actual = matriz
        for _ in range(k - 1):
            nuevo = [[0] * n for _ in range(n)]
            for i in range(n):
                for j in range(n):
                    nuevo[i][j] = sum(actual[i][m] * matriz[m][j] for m in range(n))
            actual = nuevo
        return actual

    def dibujar_grafo(self):
        try:
            self.scene.clear()  # Limpiar el área de dibujo
            self.nodos.clear()  # Limpiar la lista de nodos
            self.aristas.clear()  # Limpiar la lista de aristas

            # Obtener la matriz de pesos desde el QTableWidget
            matriz_pesos = self.obtener_matriz_pesos()

            # Convertir la matriz de pesos en una matriz de adyacencia (con 1s y 0s)
            matriz_adyacencia = self.matriz_pesos_a_adyacencia(matriz_pesos)

            # Actualizar la tabla de adyacencia en la interfaz
            self.actualizar_tabla(self.ui.tabla_adyacencia, matriz_adyacencia)

            # Calcular las matrices K=2 y K=3
            matriz_k2 = self.calcular_potencia_matriz(matriz_adyacencia, 2)
            matriz_k3 = self.calcular_potencia_matriz(matriz_adyacencia, 3)

            # Actualizar las tablas para K=2 y K=3
            self.actualizar_tabla(self.ui.tabla_k2, matriz_k2)
            self.actualizar_tabla(self.ui.tabla_k3, matriz_k3)

            # Dibujar los nodos y las aristas del grafo
            self.dibujar_nodos_y_aristas(matriz_pesos)
        except Exception as e:
            print(f"Error al dibujar el grafo: {e}")

    def dibujar_nodos_y_aristas(self, matriz):
        num_nodos = len(matriz)
        radius = 20
        width = self.graphicsView.width() - 100
        height = self.graphicsView.height() - 100
        for i in range(num_nodos):
            x = random.randint(50, width)
            y = random.randint(50, height)
            nodo = Nodo(x, y, radius, i + 1, self)
            nodo.setPos(x, y)
            self.scene.addItem(nodo)
            self.nodos.append(nodo)
        for i in range(num_nodos):
            for j in range(i + 1, num_nodos):
                peso = matriz[i][j]
                if peso > 0:
                    nodo1 = self.nodos[i]
                    nodo2 = self.nodos[j]
                    arista = Arista(nodo1, nodo2, peso, self.scene)
                    self.aristas.append(arista)
                    self.scene.addItem(arista)
                    nodo1.agregar_arista(arista)
                    nodo2.agregar_arista(arista)


if __name__ == "__main__":
    app = QtWidgets.QApplication(sys.argv)
    window = GrafoApp()
    window.show()
    sys.exit(app.exec_())
